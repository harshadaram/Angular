export interface BgMetrics {
  width:number;
  height:number;
  positionX:number;
  positionY:number;
}