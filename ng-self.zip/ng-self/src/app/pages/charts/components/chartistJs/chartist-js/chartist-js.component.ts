import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chartist-js',
  templateUrl: './chartist-js.component.html',
  styleUrls: ['./chartist-js.component.css']
})
export class ChartistJsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
